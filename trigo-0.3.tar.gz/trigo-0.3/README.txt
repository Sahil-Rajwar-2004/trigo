This library is written in python and for educational purpose, to calculate the trigonometric functions, the parameter of each functions should be integer neither boolian nor strings values.

All the parameter will be taken as radian not in degrees.

Trigonometric Functions:
sin
cos
tan
cosec
sec
cot
